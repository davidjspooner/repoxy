import Box from '@mui/material/Box';
import type { SxProps, Theme } from '@mui/material/styles';
import type { ReactNode } from 'react';

export interface ScrollableViewPortProps {
  children: ReactNode;
  className?: string;
  sx?: SxProps<Theme>;
}

export function ScrollableViewPort({ children, className, sx }: ScrollableViewPortProps) {
  const combinedClassName = ['ScrollableViewPort', className].filter(Boolean).join(' ');

  return (
    <Box
      className={combinedClassName}
      sx={[
        {
          display: 'flex',
          flexDirection: 'column',
          flex: '1 1 auto',
          width: '100%',
          maxWidth: '100%',
          height: '100%',
          maxHeight: '100%',
          minHeight: 0,
          minWidth: 0,
          alignSelf: 'stretch',
          boxSizing: 'border-box',
          overflow: 'auto',
          backgroundColor: '#f3e5f5',
          p: (theme) => theme.spacing(2),
        },
        sx,
      ]}
    >
      {children}
    </Box>
  );
}
